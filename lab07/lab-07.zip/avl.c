/*
*	Created by Nan Mihai on 11.04.2023
*	Copyright (c) 2023 Nan Mihai. All rights reserved.
*	Laborator 7 - Structuri de date și algoritmi
*	Facultatea de Automatica si Calculatoare
*	Anul Universitar 2022-2023, Seria CD
*/
#include "avl.h"

Tree createTree(T value) {
	return NULL;
}

int max(int a, int b) {
	return 0;
}

int height(Tree root) {
	return -1;
}

int balancedFactor(Tree root) {
	return 0;
}

void updateHeight(Tree root) {
	
}

Tree leftRotation(Tree x) {
	return x;
}

Tree rightRotation(Tree x) {
	return x;
}

Tree insert(Tree root, T value) {
	return root;
}

Tree minimum(Tree root) {
	return root;
}

Tree delete(Tree root, T value) {
	return root;
}

Tree freeTree(Tree root) {
	return NULL;
}